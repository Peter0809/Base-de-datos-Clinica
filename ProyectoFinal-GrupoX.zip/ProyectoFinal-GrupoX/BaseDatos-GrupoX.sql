/*
Author:Jorge Pitt�,Christian Delcid, Pierre Jaen, Jhorlin Triana
Create Date:2/12/2021
*/


--------------------------
---Scrips BASE DE DATOS---
--------------------------

Create database bd_GrupoX
GO
USE bd_GrupoX
GO
Create table Medico(
Cod_Medico varchar(5) not null primary key,Fecha_Nac date, NombreM varchar(40), 
Apellido varchar(40),Direccion varchar(100), Tipo_Contrato int,
U_Titulo varchar(50)
)
GO
Create Table Paciente(
N_Historial varchar(5) not null primary key, Fecha_Nac date, NombreP varchar(40),
Direccion varchar(100), Apellido varchar(40), Seguro_Social char(2)
)
GO
Create Table Enfermedad(
Cod_Enfermedad varchar(5) not null primary key, Sistema_Afectado varchar(100),
NombreE varchar(50), Descripcion varchar(400)
)
GO
Create Table Medico_Paciente(
Cod_Medico varchar(5) not null foreign key REFERENCES Medico(Cod_Medico),
N_Historial varchar(5) not null foreign key REFERENCES Paciente(N_Historial)
)
GO
Create Table Paciente_Enfermedad(
N_Historial varchar(5) not null foreign key REFERENCES Paciente(N_Historial),
Cod_Enfermedad varchar(5) not null foreign key REFERENCES Enfermedad(Cod_Enfermedad)
)
