---------------------------------
--CONSULTAS
---------------------------------

--Primera consulta
select AVG(datediff(yy,p.Fecha_Nac,getdate())) as 'Promedio de edad'
from Paciente p join Paciente_Enfermedad pe
on p.N_Historial = pe.N_Historial
join Enfermedad e
on e.Cod_Enfermedad = pe.Cod_Enfermedad
where e.Sistema_Afectado = 'Circulatorio'
go

--Segunda consulta
select Cod_Medico, count (Cod_Medico) as 'Cantidad de pacientes'
from Medico_Paciente
group by (Cod_Medico) 
go

--Tercera consulta
select mp.Cod_Medico, p.NombreP, p.Direccion
from Paciente p join Medico_Paciente mp
on p.N_Historial = mp.N_Historial
order by mp.Cod_Medico
go

--Cuarta Consulta
select e.NombreE as 'Nombre de enfermedad', NombreP as 'Nombre de paciente'
from Paciente p join Paciente_Enfermedad pe
on p.N_Historial = pe.N_Historial
join Enfermedad e
on pe.Cod_Enfermedad = e.Cod_Enfermedad
go

--Quinta Consulta
select count(Cod_Medico) as 'Cantidad de m�dicos menores de 30'
from Medico 
Where datediff(yy,Fecha_Nac,getdate()) < 30
go

--Sexta Consulta
select count(pe.Cod_Enfermedad) as 'Cantidad de enfermedades', p.NombreP, p.Apellido
from Paciente_Enfermedad pe join Paciente p 
on pe.N_Historial = p.N_Historial
group by p.Apellido, p.NombreP
go

--S�ptima Consulta
select Apellido, NombreM as 'Nombre del m�dico', Cod_Medico as 'C�digo del m�dico', Direccion, Tipo_Contrato, U_Titulo as 'Universidad'
from Medico
order by Apellido
go

--Octava Consulta
select m.Apellido as 'Apellido del m�dico', m.NombreM as 'Nombre del m�dico', m.Cod_Medico, e.NombreE as 'Nombre de la enfermedad', p.Apellido as 'Apellido del paciente', p.NombreP as 'Nombre del paciente', p.N_Historial as 'N�mero de historial'
from Medico m 
join Medico_Paciente mp
on m.Cod_Medico = mp.Cod_Medico
join Paciente p 
on p.N_Historial = mp.N_Historial
join Paciente_Enfermedad pe
on p.N_Historial = pe.N_Historial
join Enfermedad e
on pe.Cod_Enfermedad = e.Cod_Enfermedad
group by m.Cod_Medico, e.Cod_Enfermedad,m.Apellido, m.NombreM, e.NombreE, p.Apellido, p.NombreP, p.N_Historial
go

--Novena Consulta
select pe.Cod_Enfermedad as 'C�digo de enfermedad', count(pe.Cod_Enfermedad) as 'Cantidad de pacientes que sufren esta enfermedad', e.NombreE as 'Nombre de la enfermedad'
from Paciente_Enfermedad pe 
join Enfermedad e
on pe.Cod_Enfermedad = e.Cod_Enfermedad
join Paciente p
on pe.N_Historial = p.N_Historial
group by pe.Cod_Enfermedad, e.NombreE 
go

select 
	pe.Cod_Enfermedad as 'C�digo de enfermedad', 
		e.NombreE as 'Nombre de la enfermedad',
		(select count(s_pe.Cod_Enfermedad) from Paciente_Enfermedad s_pe Where pe.Cod_Enfermedad = s_pe.Cod_Enfermedad) as 'Cantidad de pacientes que sufren esta enfermedad' ,	
			p.NombreP as 'Nombre del paciente'
from Paciente_Enfermedad pe 
join Enfermedad e
on pe.Cod_Enfermedad = e.Cod_Enfermedad
join Paciente p
on pe.N_Historial = p.N_Historial
group by pe.Cod_Enfermedad, e.NombreE, p.NombreP
go

