/*
Author:Jorge Pitt�,Christian Delcid, Pierre Jaen, Jhorlin Triana
Create Date:2/12/2021
*/




--------------------------
---Scrips Procedimientos/Triggers---
--------------------------

USE bd_GrupoX
GO
-- PROCEDIMIENTO ALMACENADOS TABLA MEDICO--

Create Procedure InsertMedico(
@Cod_Medico varchar(5),@Fecha_Nac date, @NombreM varchar(40),
@Apellido varchar(40),@Direccion varchar(100), @Tipo_Contrato int,
@U_Titulo varchar(50)
)
as
begin
insert into Medico
Values(@Cod_Medico,@Fecha_Nac, @NombreM, @Apellido,@Direccion, @Tipo_Contrato,@U_Titulo)
end
GO

Create Procedure SelectMedico(
@NombreM int, @Apellido int, @U_Titulo int
)
as
begin 
Select (m.NombreM+ ':' + m.Apellido) as Nombre, m.U_Titulo as Titulo
from [dbo].[Medico] as m
end

GO
Create Procedure Delete_Medico
@Cod_Medico int

as
begin
Delete e
   from [dbo].[Medico] e
   where
   e.Cod_Medico = @Cod_Medico
end 
go

create procedure Update_Medico
@Cod_Medico varchar(5),@Fecha_Nac date, @NombreM varchar(40),
@Apellido varchar(40),@Direccion varchar(100), @Tipo_Contrato int,
@U_Titulo varchar(50)

as 
begin
Update e
SET
e.Fecha_Nac = @Fecha_Nac,
e.NombreM = @NombreM,
e.Apellido = @Apellido,
e.Direccion = @Direccion,
e.Tipo_Contrato = @Tipo_Contrato,
U_Titulo = @U_Titulo

 from [dbo].[Medico] e
   where
   e.Cod_Medico = @Cod_Medico
   end
go


-- PROCEDIMIENTO ALMACENADOS TABLA PACIENTE--
Create Procedure InsertPaciente(
@N_Historial varchar(5), @Fecha_Nac date, @NombreP varchar(40),
@Direccion varchar(100), @Apellido varchar(40), @Seguro_Social char(2)
)
as
begin
insert into Paciente
Values(@N_Historial, @Fecha_Nac, @NombreP,@Direccion, @Apellido, @Seguro_Social)
end

go

Create Procedure SelectPaciente(
@NombreP int ,@Apellido int
)
as
begin 
Select (p.NombreP+ ' ' + p.Apellido) as Nombre_Completo
from [dbo].[Paciente] as p
end

GO

Create Procedure Delete_Paciente
@N_Historial int

as
begin
Delete e
   from [dbo].[Paciente] e
   where
   e.N_Historial = @N_Historial
end 
go


Create procedure Update_Paciente
@N_Historial varchar(5), @Fecha_Nac date, @NombreP varchar(40),
@Direccion varchar(100), @Apellido varchar(40), @Seguro_Social char(2)

as 
begin
update e
SET

 e.Fecha_Nac = @Fecha_Nac,
 e.NombreP = @NombreP,
 e.Direccion = @Direccion,
 e.Apellido = @Apellido,
 e.Seguro_Social = @Seguro_Social

 FROM [dbo].[Paciente] e
 WHERE
 e.N_Historial = @N_Historial
 end
 go


-- PROCEDIMIENTO ALMACENADOS TABLA ENFERMEDAD--
Create Procedure InsertEnfermedad(
@Cod_Enfermedad varchar(5), @Sistema_Afectado varchar(100),
@NombreE varchar(50), @Descripcion varchar(400)
)
as
begin
insert into Enfermedad
Values(@Cod_Enfermedad, @Sistema_Afectado,@NombreE, @Descripcion)
end
GO

Create Procedure SelectEnfermedad(
@NombreE int ,@Descripcion int
)
as
begin 
Select (e.NombreE+ ':' + e.Descripcion) as Definici�n
from [dbo].[Enfermedad] as e
end

GO

Create Procedure Delete_enfermedad
@Cod_Enfermedad int

as  begin
DELETE e
from [dbo].[Enfermedad] e
WHERE
e.Cod_Enfermedad = @Cod_Enfermedad

end 
go

create procedure Update_Enfermedad
@Cod_Enfermedad varchar(5), @Sistema_Afectado varchar(100),
@NombreE varchar(50), @Descripcion varchar(400)


as begin 
update e 

SET 

e.Sistema_Afectado = @Sistema_Afectado,
e.NombreE = @NombreE,
e.Descripcion = @Descripcion

FROM [dbo].[Enfermedad] e
WHERE
e.Cod_Enfermedad = @Cod_Enfermedad

end 

-- INSERTANDO DATOS EN LAS TABLAS--
go

-- INSERTAR DATOS ENFERMEDAD--
Execute InsertEnfermedad '1231','Respiratorio','Rinitis','es un trastorno que afecta a la mucosa nasal y que produce estornudos'
go
Execute InsertEnfermedad '1232','Respiratorio','Faringitis','es causada por hinchaz�n de la parte posterior de la garganta'
go
Execute InsertEnfermedad '1233','Respiratorio','Gripe','es causada por un virus de la influenza'
go
Execute InsertEnfermedad '1234','Circulatorio','Hipertensi�n','es el t�rmino que se utiliza para describir la presi�n arterial alta.'
go
Execute InsertEnfermedad '1235','Circulatorio','Arritmia','es un latido irregular del coraz�n.'
go
Execute InsertEnfermedad '1236','Circulatorio','Hipotensi�n Postural','es cuando su presi�n sangu�nea baja cuando usted pasa de estar acostado a sentado'
go
Execute InsertEnfermedad '1237','Digestivo','Gastritis','es una inflamaci�n del revestimiento del est�mago.'
go
Execute InsertEnfermedad '1238','Digestivo','Gastroenteritis','es una inflamaci�n o hinchaz�n del est�mago y los intestinos a ra�z de un virus.'
go
Execute InsertEnfermedad '1239','Digestivo','Cirrosis Hep�tica','se refiere a la cicatrizaci�n del h�gado que da como resultado una funci�n hep�tica anormal.'
go
Execute InsertEnfermedad '12310','Inmunol�gico','Alergia Estacional','se deben a la exposici�n a sustancias suspendidas en el aire.'
go
Execute InsertEnfermedad '12311','Circulatorio','Taquicardia Esencial','t�rmino m�dico para una frecuencia card�aca de m�s de 100 latidos por minuto.'
go
Execute InsertEnfermedad '12312','Respiratorio','Pulmon�a','es una infecci�n que inflama las bolsas de aire de uno o de ambos pulmones.'
go
Execute InsertEnfermedad '12313','Digestivo','Dispepsia','es una sensaci�n de dolor o malestar en el hemiabdomen superior; a menudo es recurrente.'

go
--INSERTAR DATOS PACIENTE---------------------------------------------------------------------------------------------
Execute InsertPaciente 'abc1','1995-09-05','Carls','Ave. de las Americas','Jhonson','Si'
go
Execute InsertPaciente 'abc2','1976-10-08','Paul','Ave. Jos� Agust�n Arango','Robles','Si'
go
Execute InsertPaciente 'abc3','1989-11-17','Carla','Ave. Ricardo J. Alfaro','Suarez','No'
go

--INSERTAR DATOS MEDICO--------------------------------------------------------------------------------------------------
Execute InsertMedico 'A1B2a','2000-11-17','Fernando','Gonz�les','Via Domingo Diaz','1','Licenciatura en Medicina General'
go
Execute InsertMedico 'A1B2b','1996-12-11','Carmen','Villalba','Calle 50','2','M�dico Cirujano'
go
Execute InsertMedico 'A1B2c','1970-06-09','Ra�l','P�rez','24 de Diciembre','3','Licenciatura en Medicina General'




------------------------------------
---TRIGGER BITACORA DE CADA TABLA---
------------------------------------

create table Medico_Bitac (
Cod_Medico varchar(5),
Fecha_Nac date, 
NombreM varchar(40),
Apellido varchar(40),
Direccion varchar(100), 
Tipo_Contrato int,
U_Titulo varchar(50),
Exe_User varchar (50),
Exe_Maquina varchar (50),
Exe_Date datetime,
Exe_accion varchar (2)

)
--Trigger Insert --
Go
Create trigger Trigg_Medico_Insert
on Medico
after insert 
as 
begin
set nocount on;
Insert into dbo.Medico_Bitac
(Cod_Medico,NombreM,Apellido,Direccion,Tipo_Contrato,U_Titulo,Exe_User,Exe_Maquina,Exe_Date,Exe_accion)
select Cod_Medico, NombreM, Apellido, Direccion, Tipo_Contrato, U_Titulo, SUSER_NAME(), HOST_NAME(), GETDATE(), 'I'
from inserted
end
/*
Create Procedure InsertMedico(
@Cod_Medico varchar(5),@Fecha_Nac date, @NombreM varchar(40),
@Apellido varchar(40),@Direccion varchar(100), @Tipo_Contrato int,
@U_Titulo varchar(50)
)
as
begin
insert into Medico
Values(@Cod_Medico,@Fecha_Nac, @NombreM, @Apellido,@Direccion, @Tipo_Contrato,@U_Titulo)
end
*/

-- Trigger Delete--
Go
Create Trigger Trigg_Medico_Delete
on Medico
after delete
as 
begin 
set nocount on;

insert into dbo.Medico_Bitac
(Cod_Medico,NombreM,Apellido,Direccion,Tipo_Contrato,U_Titulo,Exe_User,Exe_Maquina,Exe_Date,Exe_accion)
select Cod_Medico, NombreM, Apellido, Direccion, Tipo_Contrato, U_Titulo, SUSER_NAME(), HOST_NAME(), GETDATE(), 'D'
from deleted
end

-- Trigger Update--
Go
Create Trigger Trigg_Medico_Update
on Medico
after update
as 
begin
set nocount on;

Insert into dbo.Medico_Bitac
(Cod_Medico,NombreM,Apellido,Direccion,Tipo_Contrato,U_Titulo,Exe_User,Exe_Maquina,Exe_Date,Exe_accion)
select Cod_Medico, NombreM, Apellido, Direccion, Tipo_Contrato, U_Titulo, SUSER_NAME(), HOST_NAME(), GETDATE(), 'UI'
from inserted

Insert into dbo.Medico_Bitac
(Cod_Medico,NombreM,Apellido,Direccion,Tipo_Contrato,U_Titulo,Exe_User,Exe_Maquina,Exe_Date,Exe_accion)
select Cod_Medico, NombreM, Apellido, Direccion, Tipo_Contrato, U_Titulo, SUSER_NAME(), HOST_NAME(), GETDATE(), 'UD'
from deleted
end


Create Table Paciente_Bitac (
N_Historial varchar(5), 
Fecha_Nac date, 
NombreP varchar(40),
Direccion varchar(100),
Apellido varchar(40), 
Seguro_Social char(2),
Exe_User varchar (50),
Exe_Maquina varchar (50),
Exe_Date datetime,
Exe_accion varchar (2)
)
-- Trigger Insert Paciente--]
Go
Create trigger Trigg_Paciente_Insert
on Paciente
after insert
as begin 
set nocount on;

insert into dbo.Paciente_Bitac
(N_Historial, Fecha_Nac, NombreP,Direccion, Apellido, Seguro_Social,Exe_User,Exe_Maquina,Exe_Date,Exe_accion) 
select N_Historial, Fecha_Nac, NombreP,Direccion, Apellido, Seguro_Social, SUSER_NAME(),HOST_NAME(), GETDATE(), 'I'
from inserted
end

--Trigger Delete Paciente--
Go
Create Trigger Trigg_Paciente_Delete
on Paciente
after delete
as 
begin 
set nocount on;

insert into dbo.Paciente_Bitac
(N_Historial, Fecha_Nac, NombreP,Direccion, Apellido, Seguro_Social,Exe_User,Exe_Maquina,Exe_Date,Exe_accion) 
select N_Historial, Fecha_Nac, NombreP,Direccion, Apellido, Seguro_Social, SUSER_NAME(),HOST_NAME(), GETDATE(), 'D'
from deleted
end


-- Trigger Update Paciente-- 
Go
Create Trigger Trigg_Paciente_Update
on Paciente
after update
as 
begin
set nocount on;

insert into dbo.Paciente_Bitac
(N_Historial, Fecha_Nac, NombreP,Direccion, Apellido, Seguro_Social,Exe_User,Exe_Maquina,Exe_Date,Exe_accion) 
select N_Historial, Fecha_Nac, NombreP,Direccion, Apellido, Seguro_Social, SUSER_NAME(),HOST_NAME(), GETDATE(), 'UI'
from inserted

insert into dbo.Paciente_Bitac
(N_Historial, Fecha_Nac, NombreP,Direccion, Apellido, Seguro_Social,Exe_User,Exe_Maquina,Exe_Date,Exe_accion) 
select N_Historial, Fecha_Nac, NombreP,Direccion, Apellido, Seguro_Social, SUSER_NAME(),HOST_NAME(), GETDATE(), 'UD'
from deleted
end


-- Enfermedad--
create table Enfermedad_Bitac(
Cod_Enfermedad varchar(5) ,
Sistema_Afectado varchar(100),
NombreE varchar(50),
Descripcion varchar(400),
Exe_User varchar (50),
Exe_Maquina varchar (50),
Exe_Date datetime,
Exe_accion varchar (2)
)
-- Trigger Insert Enfermedad-- 
Go
Create trigger Trigg_Enfermedad_Insert
on Enfermedad
after insert 
as 
begin
set nocount on;

insert into dbo.Enfermedad_Bitac
(Cod_Enfermedad  ,Sistema_Afectado ,NombreE ,Descripcion ,Exe_User ,Exe_Maquina ,Exe_Date ,Exe_accion )
select Cod_Enfermedad  ,Sistema_Afectado ,NombreE ,Descripcion, SUSER_NAME(),HOST_NAME(), GETDATE(), 'I'
from inserted
end

-- Trigger Delete Enfermedad-- 
Go
Create Trigger Trigg_Enfermedad_Delete
on Enfermedad
after delete
as 
begin 
set nocount on;
insert into dbo.Enfermedad_Bitac
(Cod_Enfermedad ,Sistema_Afectado ,NombreE ,Descripcion ,Exe_User ,Exe_Maquina ,Exe_Date ,Exe_accion )
select Cod_Enfermedad  ,Sistema_Afectado ,NombreE ,Descripcion, SUSER_NAME(),HOST_NAME(), GETDATE(), 'D'
from deleted
end


-- Trigger Update Enfermedad --
Go 
Create Trigger Trigg_Enfermedad_Update
on Enfermedad
after update
as
begin
set nocount on;
insert into dbo.Enfermedad_Bitac

(Cod_Enfermedad  ,Sistema_Afectado ,NombreE ,Descripcion ,Exe_User ,Exe_Maquina ,Exe_Date ,Exe_accion )
select Cod_Enfermedad  ,Sistema_Afectado ,NombreE ,Descripcion, SUSER_NAME(),HOST_NAME(), GETDATE(), 'UI'
from inserted

insert into dbo.Enfermedad_Bitac
(Cod_Enfermedad ,Sistema_Afectado ,NombreE ,Descripcion ,Exe_User ,Exe_Maquina ,Exe_Date ,Exe_accion )
select Cod_Enfermedad  ,Sistema_Afectado ,NombreE ,Descripcion, SUSER_NAME(),HOST_NAME(), GETDATE(), 'UD'
from deleted
end


execute SelectEnfermedad 'NombreE varchar','Descripcion int'