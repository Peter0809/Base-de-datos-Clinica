﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Consultar
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btVolver = New System.Windows.Forms.Button()
        Me.gvPacientes = New System.Windows.Forms.DataGridView()
        Me.NHistorialDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FechaNacDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NombrePDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DireccionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ApellidoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SeguroSocialDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PacienteBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BdGrupoXDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Bd_GrupoXDataSet = New Aplicativo_GrupoX.bd_GrupoXDataSet()
        Me.btConsultarAct = New System.Windows.Forms.Button()
        Me.tbNombre = New System.Windows.Forms.TextBox()
        Me.lbApellido = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbApellido = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PacienteTableAdapter = New Aplicativo_GrupoX.bd_GrupoXDataSetTableAdapters.PacienteTableAdapter()
        CType(Me.gvPacientes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PacienteBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BdGrupoXDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bd_GrupoXDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btVolver
        '
        Me.btVolver.Font = New System.Drawing.Font("Mongolian Baiti", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btVolver.Location = New System.Drawing.Point(614, 475)
        Me.btVolver.Name = "btVolver"
        Me.btVolver.Size = New System.Drawing.Size(100, 50)
        Me.btVolver.TabIndex = 32
        Me.btVolver.Text = "Volver"
        Me.btVolver.UseVisualStyleBackColor = True
        '
        'gvPacientes
        '
        Me.gvPacientes.AutoGenerateColumns = False
        Me.gvPacientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gvPacientes.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NHistorialDataGridViewTextBoxColumn, Me.FechaNacDataGridViewTextBoxColumn, Me.NombrePDataGridViewTextBoxColumn, Me.DireccionDataGridViewTextBoxColumn, Me.ApellidoDataGridViewTextBoxColumn, Me.SeguroSocialDataGridViewTextBoxColumn})
        Me.gvPacientes.DataSource = Me.PacienteBindingSource
        Me.gvPacientes.Location = New System.Drawing.Point(350, 138)
        Me.gvPacientes.Name = "gvPacientes"
        Me.gvPacientes.Size = New System.Drawing.Size(647, 291)
        Me.gvPacientes.TabIndex = 31
        '
        'NHistorialDataGridViewTextBoxColumn
        '
        Me.NHistorialDataGridViewTextBoxColumn.DataPropertyName = "N_Historial"
        Me.NHistorialDataGridViewTextBoxColumn.HeaderText = "N_Historial"
        Me.NHistorialDataGridViewTextBoxColumn.Name = "NHistorialDataGridViewTextBoxColumn"
        '
        'FechaNacDataGridViewTextBoxColumn
        '
        Me.FechaNacDataGridViewTextBoxColumn.DataPropertyName = "Fecha_Nac"
        Me.FechaNacDataGridViewTextBoxColumn.HeaderText = "Fecha_Nac"
        Me.FechaNacDataGridViewTextBoxColumn.Name = "FechaNacDataGridViewTextBoxColumn"
        '
        'NombrePDataGridViewTextBoxColumn
        '
        Me.NombrePDataGridViewTextBoxColumn.DataPropertyName = "NombreP"
        Me.NombrePDataGridViewTextBoxColumn.HeaderText = "NombreP"
        Me.NombrePDataGridViewTextBoxColumn.Name = "NombrePDataGridViewTextBoxColumn"
        '
        'DireccionDataGridViewTextBoxColumn
        '
        Me.DireccionDataGridViewTextBoxColumn.DataPropertyName = "Direccion"
        Me.DireccionDataGridViewTextBoxColumn.HeaderText = "Direccion"
        Me.DireccionDataGridViewTextBoxColumn.Name = "DireccionDataGridViewTextBoxColumn"
        '
        'ApellidoDataGridViewTextBoxColumn
        '
        Me.ApellidoDataGridViewTextBoxColumn.DataPropertyName = "Apellido"
        Me.ApellidoDataGridViewTextBoxColumn.HeaderText = "Apellido"
        Me.ApellidoDataGridViewTextBoxColumn.Name = "ApellidoDataGridViewTextBoxColumn"
        '
        'SeguroSocialDataGridViewTextBoxColumn
        '
        Me.SeguroSocialDataGridViewTextBoxColumn.DataPropertyName = "Seguro_Social"
        Me.SeguroSocialDataGridViewTextBoxColumn.HeaderText = "Seguro_Social"
        Me.SeguroSocialDataGridViewTextBoxColumn.Name = "SeguroSocialDataGridViewTextBoxColumn"
        '
        'PacienteBindingSource
        '
        Me.PacienteBindingSource.DataMember = "Paciente"
        Me.PacienteBindingSource.DataSource = Me.BdGrupoXDataSetBindingSource
        '
        'BdGrupoXDataSetBindingSource
        '
        Me.BdGrupoXDataSetBindingSource.DataSource = Me.Bd_GrupoXDataSet
        Me.BdGrupoXDataSetBindingSource.Position = 0
        '
        'Bd_GrupoXDataSet
        '
        Me.Bd_GrupoXDataSet.DataSetName = "bd_GrupoXDataSet"
        Me.Bd_GrupoXDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btConsultarAct
        '
        Me.btConsultarAct.Font = New System.Drawing.Font("Mongolian Baiti", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btConsultarAct.Location = New System.Drawing.Point(138, 475)
        Me.btConsultarAct.Name = "btConsultarAct"
        Me.btConsultarAct.Size = New System.Drawing.Size(100, 50)
        Me.btConsultarAct.TabIndex = 30
        Me.btConsultarAct.Text = "Consultar"
        Me.btConsultarAct.UseVisualStyleBackColor = True
        '
        'tbNombre
        '
        Me.tbNombre.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbNombre.Location = New System.Drawing.Point(173, 138)
        Me.tbNombre.Name = "tbNombre"
        Me.tbNombre.Size = New System.Drawing.Size(100, 26)
        Me.tbNombre.TabIndex = 25
        '
        'lbApellido
        '
        Me.lbApellido.AutoSize = True
        Me.lbApellido.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbApellido.Location = New System.Drawing.Point(54, 141)
        Me.lbApellido.Name = "lbApellido"
        Me.lbApellido.Size = New System.Drawing.Size(60, 16)
        Me.lbApellido.TabIndex = 24
        Me.lbApellido.Text = "Nombre"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(54, 191)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 16)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Apellido"
        '
        'tbApellido
        '
        Me.tbApellido.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApellido.Location = New System.Drawing.Point(173, 185)
        Me.tbApellido.Name = "tbApellido"
        Me.tbApellido.Size = New System.Drawing.Size(100, 26)
        Me.tbApellido.TabIndex = 21
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Mongolian Baiti", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(356, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(285, 37)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Consultar paciente"
        '
        'PacienteTableAdapter
        '
        Me.PacienteTableAdapter.ClearBeforeFill = True
        '
        'Consultar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1032, 576)
        Me.Controls.Add(Me.btVolver)
        Me.Controls.Add(Me.gvPacientes)
        Me.Controls.Add(Me.btConsultarAct)
        Me.Controls.Add(Me.tbNombre)
        Me.Controls.Add(Me.lbApellido)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbApellido)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Consultar"
        Me.Text = "Consultar"
        CType(Me.gvPacientes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PacienteBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BdGrupoXDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bd_GrupoXDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btVolver As Button
    Friend WithEvents gvPacientes As DataGridView
    Friend WithEvents btConsultarAct As Button
    Friend WithEvents tbNombre As TextBox
    Friend WithEvents lbApellido As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents tbApellido As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents BdGrupoXDataSetBindingSource As BindingSource
    Friend WithEvents Bd_GrupoXDataSet As bd_GrupoXDataSet
    Friend WithEvents PacienteBindingSource As BindingSource
    Friend WithEvents PacienteTableAdapter As bd_GrupoXDataSetTableAdapters.PacienteTableAdapter
    Friend WithEvents NHistorialDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FechaNacDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NombrePDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DireccionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ApellidoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SeguroSocialDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
