﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'Bd_GrupoXDataSet.Enfermedad' Puede moverla o quitarla según sea necesario.
        Me.EnfermedadTableAdapter.Fill(Me.Bd_GrupoXDataSet.Enfermedad)

    End Sub

    Private Sub btInsert_Click(sender As Object, e As EventArgs) Handles btInsert.Click
        Insertar.Show()
        Me.Hide()
    End Sub

    Private Sub btDelete_Click(sender As Object, e As EventArgs) Handles btDelete.Click
        Eliminar.Show()
        Me.Hide()

    End Sub

    Private Sub btSalir_Click(sender As Object, e As EventArgs) Handles btSalir.Click
        Me.Close()
    End Sub

    Private Sub btSelect_Click(sender As Object, e As EventArgs) Handles btSelect.Click
        Consultar.Show()
        Me.Hide()

    End Sub

    Private Sub btUpdate_Click(sender As Object, e As EventArgs) Handles btUpdate.Click
        Actualizar.Show()
        Me.Hide()
    End Sub
End Class
