﻿Public Class Consultar


    Private Sub Consultar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'Bd_GrupoXDataSet.Paciente' Puede moverla o quitarla según sea necesario.
        Me.PacienteTableAdapter.Fill(Me.Bd_GrupoXDataSet.Paciente)

    End Sub

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub btConsultarAct_Click(sender As Object, e As EventArgs) Handles btConsultarAct.Click
        Me.PacienteTableAdapter.SelectPaciente(Bd_GrupoXDataSet.Paciente, tbNombre.Text, tbApellido.Text)

    End Sub
End Class