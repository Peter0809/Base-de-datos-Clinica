﻿Public Class Actualizar
    Private Sub btActualizarAct_Click(sender As Object, e As EventArgs) Handles btActualizarAct.Click
        Me.PacienteTableAdapter.Actualizar_Existente(Bd_GrupoXDataSet.Paciente, tbNHistorial.Text, tbFecha.Text, tbNombre.Text, tbDireccion.Text, tbApellido.Text, tbSeguro.Text)
        Me.PacienteTableAdapter.Fill(Me.Bd_GrupoXDataSet.Paciente)
    End Sub

    Private Sub Actualizar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'Bd_GrupoXDataSet.Paciente' Puede moverla o quitarla según sea necesario.
        Me.PacienteTableAdapter.Fill(Me.Bd_GrupoXDataSet.Paciente)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Show()
        Me.Hide()
    End Sub
End Class