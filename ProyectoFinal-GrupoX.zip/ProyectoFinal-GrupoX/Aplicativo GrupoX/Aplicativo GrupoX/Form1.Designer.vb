﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.EnfermedadBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btSelect = New System.Windows.Forms.Button()
        Me.btDelete = New System.Windows.Forms.Button()
        Me.btInsert = New System.Windows.Forms.Button()
        Me.btUpdate = New System.Windows.Forms.Button()
        Me.gbPacientes = New System.Windows.Forms.GroupBox()
        Me.btSalir = New System.Windows.Forms.Button()
        Me.BdGrupoXDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Bd_GrupoXDataSet = New Aplicativo_GrupoX.bd_GrupoXDataSet()
        Me.EnfermedadTableAdapter = New Aplicativo_GrupoX.bd_GrupoXDataSetTableAdapters.EnfermedadTableAdapter()
        CType(Me.EnfermedadBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbPacientes.SuspendLayout()
        CType(Me.BdGrupoXDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bd_GrupoXDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Mongolian Baiti", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(244, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(357, 37)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Centro Médico GrupoX"
        '
        'EnfermedadBindingSource
        '
        Me.EnfermedadBindingSource.DataMember = "Enfermedad"
        Me.EnfermedadBindingSource.DataSource = Me.BdGrupoXDataSetBindingSource
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Mongolian Baiti", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(69, 101)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(280, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Sistema de control de pacientes "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Mongolian Baiti", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(69, 153)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(364, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "¿Qué desea hacer con la tabla de los pacientes?"
        '
        'btSelect
        '
        Me.btSelect.Font = New System.Drawing.Font("Mongolian Baiti", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btSelect.Location = New System.Drawing.Point(6, 77)
        Me.btSelect.Name = "btSelect"
        Me.btSelect.Size = New System.Drawing.Size(102, 48)
        Me.btSelect.TabIndex = 3
        Me.btSelect.Text = "Consultar"
        Me.btSelect.UseVisualStyleBackColor = True
        '
        'btDelete
        '
        Me.btDelete.Font = New System.Drawing.Font("Mongolian Baiti", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btDelete.Location = New System.Drawing.Point(222, 77)
        Me.btDelete.Name = "btDelete"
        Me.btDelete.Size = New System.Drawing.Size(102, 48)
        Me.btDelete.TabIndex = 4
        Me.btDelete.Text = "Eliminar"
        Me.btDelete.UseVisualStyleBackColor = True
        '
        'btInsert
        '
        Me.btInsert.Font = New System.Drawing.Font("Mongolian Baiti", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btInsert.Location = New System.Drawing.Point(114, 77)
        Me.btInsert.Name = "btInsert"
        Me.btInsert.Size = New System.Drawing.Size(102, 48)
        Me.btInsert.TabIndex = 5
        Me.btInsert.Text = "Insertar"
        Me.btInsert.UseVisualStyleBackColor = True
        '
        'btUpdate
        '
        Me.btUpdate.Font = New System.Drawing.Font("Mongolian Baiti", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btUpdate.Location = New System.Drawing.Point(330, 77)
        Me.btUpdate.Name = "btUpdate"
        Me.btUpdate.Size = New System.Drawing.Size(102, 48)
        Me.btUpdate.TabIndex = 6
        Me.btUpdate.Text = "Actualizar"
        Me.btUpdate.UseVisualStyleBackColor = True
        '
        'gbPacientes
        '
        Me.gbPacientes.Controls.Add(Me.btSelect)
        Me.gbPacientes.Controls.Add(Me.btUpdate)
        Me.gbPacientes.Controls.Add(Me.btDelete)
        Me.gbPacientes.Controls.Add(Me.btInsert)
        Me.gbPacientes.Location = New System.Drawing.Point(181, 231)
        Me.gbPacientes.Name = "gbPacientes"
        Me.gbPacientes.Size = New System.Drawing.Size(451, 180)
        Me.gbPacientes.TabIndex = 7
        Me.gbPacientes.TabStop = False
        Me.gbPacientes.Text = "Opciones"
        '
        'btSalir
        '
        Me.btSalir.Font = New System.Drawing.Font("Mongolian Baiti", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btSalir.Location = New System.Drawing.Point(677, 426)
        Me.btSalir.Name = "btSalir"
        Me.btSalir.Size = New System.Drawing.Size(102, 48)
        Me.btSalir.TabIndex = 8
        Me.btSalir.Text = "Salir"
        Me.btSalir.UseVisualStyleBackColor = True
        '
        'BdGrupoXDataSetBindingSource
        '
        Me.BdGrupoXDataSetBindingSource.DataSource = Me.Bd_GrupoXDataSet
        Me.BdGrupoXDataSetBindingSource.Position = 0
        '
        'Bd_GrupoXDataSet
        '
        Me.Bd_GrupoXDataSet.DataSetName = "bd_GrupoXDataSet"
        Me.Bd_GrupoXDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EnfermedadTableAdapter
        '
        Me.EnfermedadTableAdapter.ClearBeforeFill = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(815, 495)
        Me.Controls.Add(Me.btSalir)
        Me.Controls.Add(Me.gbPacientes)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.EnfermedadBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbPacientes.ResumeLayout(False)
        CType(Me.BdGrupoXDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bd_GrupoXDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Bd_GrupoXDataSet As bd_GrupoXDataSet
    Friend WithEvents BdGrupoXDataSetBindingSource As BindingSource
    Friend WithEvents EnfermedadBindingSource As BindingSource
    Friend WithEvents EnfermedadTableAdapter As bd_GrupoXDataSetTableAdapters.EnfermedadTableAdapter
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btSelect As Button
    Friend WithEvents btDelete As Button
    Friend WithEvents btInsert As Button
    Friend WithEvents btUpdate As Button
    Friend WithEvents gbPacientes As GroupBox
    Friend WithEvents btSalir As Button
End Class
