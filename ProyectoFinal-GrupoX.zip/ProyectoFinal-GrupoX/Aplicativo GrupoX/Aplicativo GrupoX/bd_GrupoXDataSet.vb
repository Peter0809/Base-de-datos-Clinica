﻿

Partial Class bd_GrupoXDataSet
End Class

Namespace bd_GrupoXDataSetTableAdapters

    Partial Public Class PacienteTableAdapter
    End Class
End Namespace
