﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Actualizar
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.gvPacientes = New System.Windows.Forms.DataGridView()
        Me.NHistorialDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FechaNacDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NombrePDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DireccionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ApellidoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SeguroSocialDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PacienteBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BdGrupoXDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Bd_GrupoXDataSet = New Aplicativo_GrupoX.bd_GrupoXDataSet()
        Me.btActualizarAct = New System.Windows.Forms.Button()
        Me.tbDireccion = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tbSeguro = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tbNombre = New System.Windows.Forms.TextBox()
        Me.lbApellido = New System.Windows.Forms.Label()
        Me.tbFecha = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbApellido = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbNHistorial = New System.Windows.Forms.TextBox()
        Me.lbNHistorial = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PacienteTableAdapter = New Aplicativo_GrupoX.bd_GrupoXDataSetTableAdapters.PacienteTableAdapter()
        CType(Me.gvPacientes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PacienteBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BdGrupoXDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bd_GrupoXDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Mongolian Baiti", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(614, 475)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 50)
        Me.Button1.TabIndex = 32
        Me.Button1.Text = "Volver"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'gvPacientes
        '
        Me.gvPacientes.AutoGenerateColumns = False
        Me.gvPacientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gvPacientes.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NHistorialDataGridViewTextBoxColumn, Me.FechaNacDataGridViewTextBoxColumn, Me.NombrePDataGridViewTextBoxColumn, Me.DireccionDataGridViewTextBoxColumn, Me.ApellidoDataGridViewTextBoxColumn, Me.SeguroSocialDataGridViewTextBoxColumn})
        Me.gvPacientes.DataSource = Me.PacienteBindingSource
        Me.gvPacientes.Location = New System.Drawing.Point(350, 138)
        Me.gvPacientes.Name = "gvPacientes"
        Me.gvPacientes.Size = New System.Drawing.Size(647, 291)
        Me.gvPacientes.TabIndex = 31
        '
        'NHistorialDataGridViewTextBoxColumn
        '
        Me.NHistorialDataGridViewTextBoxColumn.DataPropertyName = "N_Historial"
        Me.NHistorialDataGridViewTextBoxColumn.HeaderText = "N_Historial"
        Me.NHistorialDataGridViewTextBoxColumn.Name = "NHistorialDataGridViewTextBoxColumn"
        '
        'FechaNacDataGridViewTextBoxColumn
        '
        Me.FechaNacDataGridViewTextBoxColumn.DataPropertyName = "Fecha_Nac"
        Me.FechaNacDataGridViewTextBoxColumn.HeaderText = "Fecha_Nac"
        Me.FechaNacDataGridViewTextBoxColumn.Name = "FechaNacDataGridViewTextBoxColumn"
        '
        'NombrePDataGridViewTextBoxColumn
        '
        Me.NombrePDataGridViewTextBoxColumn.DataPropertyName = "NombreP"
        Me.NombrePDataGridViewTextBoxColumn.HeaderText = "NombreP"
        Me.NombrePDataGridViewTextBoxColumn.Name = "NombrePDataGridViewTextBoxColumn"
        '
        'DireccionDataGridViewTextBoxColumn
        '
        Me.DireccionDataGridViewTextBoxColumn.DataPropertyName = "Direccion"
        Me.DireccionDataGridViewTextBoxColumn.HeaderText = "Direccion"
        Me.DireccionDataGridViewTextBoxColumn.Name = "DireccionDataGridViewTextBoxColumn"
        '
        'ApellidoDataGridViewTextBoxColumn
        '
        Me.ApellidoDataGridViewTextBoxColumn.DataPropertyName = "Apellido"
        Me.ApellidoDataGridViewTextBoxColumn.HeaderText = "Apellido"
        Me.ApellidoDataGridViewTextBoxColumn.Name = "ApellidoDataGridViewTextBoxColumn"
        '
        'SeguroSocialDataGridViewTextBoxColumn
        '
        Me.SeguroSocialDataGridViewTextBoxColumn.DataPropertyName = "Seguro_Social"
        Me.SeguroSocialDataGridViewTextBoxColumn.HeaderText = "Seguro_Social"
        Me.SeguroSocialDataGridViewTextBoxColumn.Name = "SeguroSocialDataGridViewTextBoxColumn"
        '
        'PacienteBindingSource
        '
        Me.PacienteBindingSource.DataMember = "Paciente"
        Me.PacienteBindingSource.DataSource = Me.BdGrupoXDataSetBindingSource
        '
        'BdGrupoXDataSetBindingSource
        '
        Me.BdGrupoXDataSetBindingSource.DataSource = Me.Bd_GrupoXDataSet
        Me.BdGrupoXDataSetBindingSource.Position = 0
        '
        'Bd_GrupoXDataSet
        '
        Me.Bd_GrupoXDataSet.DataSetName = "bd_GrupoXDataSet"
        Me.Bd_GrupoXDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btActualizarAct
        '
        Me.btActualizarAct.Font = New System.Drawing.Font("Mongolian Baiti", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btActualizarAct.Location = New System.Drawing.Point(138, 475)
        Me.btActualizarAct.Name = "btActualizarAct"
        Me.btActualizarAct.Size = New System.Drawing.Size(100, 50)
        Me.btActualizarAct.TabIndex = 30
        Me.btActualizarAct.Text = "Actualizar"
        Me.btActualizarAct.UseVisualStyleBackColor = True
        '
        'tbDireccion
        '
        Me.tbDireccion.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbDireccion.Location = New System.Drawing.Point(192, 337)
        Me.tbDireccion.Name = "tbDireccion"
        Me.tbDireccion.Size = New System.Drawing.Size(100, 26)
        Me.tbDireccion.TabIndex = 29
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(63, 340)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 16)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "Dirección"
        '
        'tbSeguro
        '
        Me.tbSeguro.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSeguro.Location = New System.Drawing.Point(192, 388)
        Me.tbSeguro.Name = "tbSeguro"
        Me.tbSeguro.Size = New System.Drawing.Size(100, 26)
        Me.tbSeguro.TabIndex = 27
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(54, 391)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 16)
        Me.Label4.TabIndex = 26
        Me.Label4.Text = "Seguro Social"
        '
        'tbNombre
        '
        Me.tbNombre.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbNombre.Location = New System.Drawing.Point(192, 189)
        Me.tbNombre.Name = "tbNombre"
        Me.tbNombre.Size = New System.Drawing.Size(100, 26)
        Me.tbNombre.TabIndex = 25
        '
        'lbApellido
        '
        Me.lbApellido.AutoSize = True
        Me.lbApellido.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbApellido.Location = New System.Drawing.Point(73, 192)
        Me.lbApellido.Name = "lbApellido"
        Me.lbApellido.Size = New System.Drawing.Size(60, 16)
        Me.lbApellido.TabIndex = 24
        Me.lbApellido.Text = "Nombre"
        '
        'tbFecha
        '
        Me.tbFecha.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbFecha.Location = New System.Drawing.Point(192, 291)
        Me.tbFecha.Name = "tbFecha"
        Me.tbFecha.Size = New System.Drawing.Size(100, 26)
        Me.tbFecha.TabIndex = 23
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(73, 242)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 16)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Apellido"
        '
        'tbApellido
        '
        Me.tbApellido.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApellido.Location = New System.Drawing.Point(192, 236)
        Me.tbApellido.Name = "tbApellido"
        Me.tbApellido.Size = New System.Drawing.Size(100, 26)
        Me.tbApellido.TabIndex = 21
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(36, 294)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(138, 16)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Fecha de nacimiento"
        '
        'tbNHistorial
        '
        Me.tbNHistorial.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbNHistorial.Location = New System.Drawing.Point(192, 138)
        Me.tbNHistorial.Name = "tbNHistorial"
        Me.tbNHistorial.Size = New System.Drawing.Size(100, 26)
        Me.tbNHistorial.TabIndex = 19
        '
        'lbNHistorial
        '
        Me.lbNHistorial.AutoSize = True
        Me.lbNHistorial.Font = New System.Drawing.Font("Mongolian Baiti", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbNHistorial.Location = New System.Drawing.Point(54, 141)
        Me.lbNHistorial.Name = "lbNHistorial"
        Me.lbNHistorial.Size = New System.Drawing.Size(109, 16)
        Me.lbNHistorial.TabIndex = 18
        Me.lbNHistorial.Text = "No. de Historial"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Mongolian Baiti", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(326, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(415, 37)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Actualizar info del paciente"
        '
        'PacienteTableAdapter
        '
        Me.PacienteTableAdapter.ClearBeforeFill = True
        '
        'Actualizar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1032, 576)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.gvPacientes)
        Me.Controls.Add(Me.btActualizarAct)
        Me.Controls.Add(Me.tbDireccion)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tbSeguro)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tbNombre)
        Me.Controls.Add(Me.lbApellido)
        Me.Controls.Add(Me.tbFecha)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbApellido)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tbNHistorial)
        Me.Controls.Add(Me.lbNHistorial)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Actualizar"
        Me.Text = "Actualizar"
        CType(Me.gvPacientes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PacienteBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BdGrupoXDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bd_GrupoXDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents gvPacientes As DataGridView
    Friend WithEvents btActualizarAct As Button
    Friend WithEvents tbDireccion As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents tbSeguro As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents tbNombre As TextBox
    Friend WithEvents lbApellido As Label
    Friend WithEvents tbFecha As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents tbApellido As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents tbNHistorial As TextBox
    Friend WithEvents lbNHistorial As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents BdGrupoXDataSetBindingSource As BindingSource
    Friend WithEvents Bd_GrupoXDataSet As bd_GrupoXDataSet
    Friend WithEvents PacienteBindingSource As BindingSource
    Friend WithEvents PacienteTableAdapter As bd_GrupoXDataSetTableAdapters.PacienteTableAdapter
    Friend WithEvents NHistorialDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FechaNacDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NombrePDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DireccionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ApellidoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SeguroSocialDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
